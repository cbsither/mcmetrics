# tests/__init__.py
"""Test utilities package. Intentionally minimal."""